# coding:utf-8
import time
import unittest
import warnings
from appium import webdriver
from common.base import Base
from common.config import road_transport
from page.login import Login
from page.search import Search
import ddt
from common.readexcel import ExcelUtil


filepath = "testdata.xlsx"
sheetName = "Sheet1"
data = ExcelUtil(filepath, sheetName)
testdata=data.dict_data()
print(testdata)



@ddt.ddt
class SearchReservation(unittest.TestCase):
    """搜索预订测试"""
    @classmethod
    def setUpClass(cls):
        cls.driver = webdriver.Remote('http://127.0.0.1:4723/wd/hub', road_transport())
        cls.base = Base(cls.driver)
        cls.n = Search(cls.driver)
        cls.a = Login(cls.driver)
        # a = cls.driver.page_source
        # print(a)
        warnings.simplefilter("ignore", ResourceWarning)  # 忽略警告日志
        time.sleep(6)

    @classmethod
    def tearDownClass(cls):
        pass

    def setUp(self):
        print('* * * Start * * *')

    def tearDown(self):
        print('* * * End * * *')

    @ddt.data(*testdata)
    def test01(self,testdata):
        """输入出发站到达站"""
        try:
            start = testdata["start"]
            end = testdata["end"]
            self.n.deparstaion(start, end)
            result = self.base.is_element_exist('查询')
            self.assertTrue(result)

        except Exception as msg:
            print('测试Fail,异常原因:', msg)
            now_time = time.strftime("%Y%m%d.%H.%M.%S")
            self.base.get_screenshot_as_file('%s.png' % now_time)
            raise

if __name__ == "__main__":
    unittest.main()
