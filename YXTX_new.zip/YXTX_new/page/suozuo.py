# coding:utf-8
from appium import webdriver
from common.base import Base
import time


class Search(Base):  # 搜索预订

    def deparstaion(self, start, end):
        """出发站/到达站选择"""
        # self.click_element('xpath', '//*[@text="汽车票"]')
        self.click_element('xpath', '//android.widget.TextView[@text="出发城市"]')     # 先点始发站击输入框
        self.send_key('xpath', '//android.widget.EditText[@text="出发站(如北京/beijing/bj)"]', start)  # 参数化输入出发站
        time.sleep(2)
        self.click_element('xpath', '//android.widget.TextView[@text="安国市"]')    # 点击出发站
        time.sleep(2)
        # self.click_element('xpath', '//android.view.View[@text="A"]')
        # time.sleep(2)nizh
        self.send_key('xpath', '//android.widget.EditText[@text="出发站(如北京/beijing/bj)"]', end)  # 参数化输入到达站
        self.click_element('xpath', '//android.widget.TextView[@text="安国市"]')
        # self.send_key('id', 'arrSearchCity', '北京市')
        self.click_element('xpath', '//android.view.ViewGroup[@index="2"]')
        time.sleep(2)


if __name__ == "__main__":
    a = Search(Base)
    a.deparstaion('北京', '安国')